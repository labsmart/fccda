//
//  Evento.m
//  ProjetoGrupo4
//
//  Created by aluno on 20/05/15.
//  Copyright (c) 2015 Grupo04. All rights reserved.
//

#import "Evento.h"

@implementation Evento
@synthesize tipo, nome, local, data, horario, classificacao;

-(id) initWithTipo:(NSString *) tipoInicial
           andNome:(NSString *) nomeInicial
           andLocal:(NSString *) localInicial
           andData:(NSString *) dataInicial
           andHorario:(NSString *) horarioInicial
           andClassificacao:(NSString *) classificacaoInicial;{
    if ((self = [super init])) {
        self.tipo = tipoInicial;
        self.nome = nomeInicial;
        self.local = localInicial;
        self.data = dataInicial;
        self.horario = horarioInicial;
        self.classificacao = classificacaoInicial;
    }
    return self;
}

//-(void) dealloc {
//    [tipo release];
//    [nome release];
//    [local release];
//    [data release];
//    [horario release];
//    [classificacao release];
//    [super dealloc];
//}

@end