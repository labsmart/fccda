//
//  Evento.h
//  ProjetoGrupo4
//
//  Created by aluno on 20/05/15.
//  Copyright (c) 2015 Grupo04. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Evento : NSObject {
    NSString *tipo;
    NSString *nome;
    NSString *local;
    NSString *data;
    NSString *horario;
    NSString *classificacao;
    
    
}

-(id) initWithTipo:(NSString *) tipoInicial
           andNome:(NSString *) nomeInicial
           andLocal:(NSString *) localInicial
           andData:(NSString *) dataInicial
           andHorario:(NSString *) horarioInicial
           andClassificacao:(NSString *) classificacaoInicial;

@property (nonatomic, retain) NSString *tipo;
@property (nonatomic, retain) NSString *nome;
@property (nonatomic, retain) NSString *local;
@property (nonatomic, retain) NSString *data;
@property (nonatomic, retain) NSString *horario;
@property (nonatomic, retain) NSString *classificacao;

@end
