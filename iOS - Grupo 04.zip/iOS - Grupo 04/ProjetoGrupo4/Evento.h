//
//  Evento.h
//  ProjetoGrupo4
//
//  Created by aluno on 20/05/15.
//  Copyright (c) 2015 Grupo04. All rights reserved.
//

#ifndef ProjetoGrupo4_Evento_h
#define ProjetoGrupo4_Evento_h
@interface Contato : NSObject {
    NSString *nome;
    NSString *telefone;
}
-(id) initWithNome:(NSString *) nomeInicial andTelefone:(NSString *) telInicial;

@property (nonatomic, retain) NSString *nome;
@property (nonatomic, retain) NSString *telefone;

#endif
