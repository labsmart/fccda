//
//  ViewController.m
//  ProjetoGrupo4
//
//  Created by aluno on 20/05/15.
//  Copyright (c) 2015 Grupo04. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
     [super viewDidLoad];
     [self loadEvents];
 }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) loadEvents {
    NSString *plistCaminho = [[NSBundle mainBundle]
            pathForResource:@"eventos"  ofType:@"plist"];
    NSDictionary *pl = [NSDictionary
                        dictionaryWithContentsOfFile:plistCaminho];
    NSArray *dados = [pl objectForKey:@"eventos"];
    eventos = [[NSMutableArray alloc] init];
    for (NSDictionary *item in dados) {
        NSString *tipo = [item objectForKey:@"tipo"];
        NSString *nome = [item objectForKey:@"nome"];
        NSString *local = [item objectForKey:@"local"];
        NSString *data = [item objectForKey:@"data"];
        NSString *horario = [item objectForKey:@"horario"];
        NSString *classificacao = [item objectForKey:@"classificacao"];
//        Evento *c = [[Evento alloc] initWithTipo:tipo
//                                        andNome:nome
//                                        andLocal:local
//                                        andData:data
//                                        andHorario:horario
//                                        andClassificacao:classificacao];
//        [eventos addObject:c];
//
//        [c release];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
