//
//  ViewController.h
//  ProjetoGrupo4
//
//  Created by aluno on 20/05/15.
//  Copyright (c) 2015 Grupo04. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController :UIViewController<UITableViewDelegate,UITableViewDataSource> {
    NSMutableArray *eventos;
}

@property (retain, nonatomic) IBOutlet UITableView *tabelaEventos;

@end