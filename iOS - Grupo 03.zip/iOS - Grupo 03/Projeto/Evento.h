//

//  Contato.h

//  TableViewSimpleContactList

//

//  Created by aluno on 5/13/15.

//  Lucas de Sá Moreira Bragança - 22314

//  Rafael José dos Reis Macieira - 28733



#import <UIKit/UIKit.h>



@interface Evento : NSObject{
    
    NSString *nome;
    
    NSString *local;
    
    NSString *horario;
    
    NSString *descricao;
    
    NSString *link;
    
    
}



-(id) initWithNome:(NSString *) nomeInicial

       andLocal:(NSString *) localInicial

        andHorario:(NSString*) horarioInicial

      andDescricao:(NSString *) descricaoInicial

           andLink:(NSString*) linkInicial;





@property (nonatomic, retain) NSString *nome;

@property (nonatomic, retain) NSString *local;

@property (nonatomic, retain) NSString *horario;

@property (nonatomic, retain) NSString *descricao;

@property (nonatomic, retain) NSString *link;




@end


