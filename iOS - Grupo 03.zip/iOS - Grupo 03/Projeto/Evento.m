//
//  Contato.m
//  TableViewSimpleContactList
//
//  Created by aluno on 5/13/15.

//  Lucas de Sá Moreira Bragança - 22314

//  Rafael José dos Reis Macieira - 28733


#import "Evento.h"

@implementation Evento

@synthesize nome, local, horario, descricao, link;

-(id) initWithNome:(NSString *) nomeInicial

       andLocal:(NSString *) localInicial

        andHorario:(NSString *)horarioInicial

         andDescricao:(NSString *)descricaoInicial
            andLink:(NSString *)linkInicial
            {
    
    if ((self = [super init])) {
        
        self.nome = nomeInicial;
        self.local = localInicial;
        self.horario = horarioInicial;
        self.descricao = descricaoInicial;
        self.link = linkInicial;
        
    }
    
    return self;
}
@end