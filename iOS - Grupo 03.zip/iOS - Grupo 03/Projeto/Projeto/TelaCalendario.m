//
//  TelaCalendario.m
//  Projeto
//
//  Created by aluno on 5/20/15.

//  Lucas de Sá Moreira Bragança - 22314

//  Rafael José dos Reis Macieira - 28733

#import "TelaCalendario.h"
#import "Evento.h"
#import "TelaEventos.h"

@interface TelaCalendario ()

@end

@implementation TelaCalendario

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Calendário";
    [self loadContacts:@"6"];
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

//****************************

-(void) loadContacts:(NSString*) chave {
    
    NSString *plistCaminho = [[NSBundle mainBundle]
                              pathForResource:@"banco"  ofType:@"plist"];
    NSDictionary *pl = [NSDictionary
                        dictionaryWithContentsOfFile:plistCaminho];
    
    NSArray *dados = [pl objectForKey:chave];//nome da chave que é pra selecionar (vai vir como parametro na função)
    
    inserirEventos = [[NSMutableArray alloc] init];
    for
        (NSDictionary *item in dados) {
            NSString *nome = [item objectForKey:@"nome"];
            NSString *horario = [item objectForKey:@"horario"];
            NSString *local = [item objectForKey:@"local"];
            NSString *descricao = [item objectForKey:@"descricao"];
            NSString *link = [item objectForKey:@"link" ];
            
            Evento *c = [[Evento alloc] initWithNome:nome
                                            andLocal:local
                                          andHorario:horario
                                            andDescricao:descricao
                                            andLink:link];
            [inserirEventos addObject:c];
        }
}
//*****************************

- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section {
    return inserirEventos.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CelulaContatoCacheID = @"CelulaContatoCacheID";
    UITableViewCell *cell = [self.tabelaDeEventos
                             dequeueReusableCellWithIdentifier:CelulaContatoCacheID];
    if (!cell) {
        cell = [[UITableViewCell alloc]
                initWithStyle:UITableViewCellStyleDefault
                reuseIdentifier:CelulaContatoCacheID];
    }
    Evento *contato = [inserirEventos objectAtIndex:indexPath.row];
    cell.textLabel.text = contato.nome;
    return cell;
}

- (void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    Evento *contato = [inserirEventos objectAtIndex:indexPath.row];
    NSString *msg =
    [NSString stringWithFormat:@" %@\nHorário: %@\nLocal: %@",
     contato.nome, contato.horario,  contato.local];
    
    /***********************/
    
    ev = [[Evento alloc] init];
    ev = contato;
    ev.descricao = contato.descricao;
    ev.link = contato.link;
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil
                                                    message:msg
                                                   delegate:self
                                          cancelButtonTitle:@"Voltar"
                                          otherButtonTitles:@"Ir para Evento",nil];
    [alert show];
    [self.tabelaDeEventos deselectRowAtIndexPath:indexPath animated:YES];
    
    
}


//Método do AlertView
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    
    if (buttonIndex != 0){
        
        
        
        TelaEventos *t = [[TelaEventos alloc]initComObjeto:ev ];//criar outro "construtor"
        
        [self.navigationController pushViewController:t animated:YES];
        
        
        
    }
    
    else {NSLog(@"nao faz nada");}
    
}

//Incrementa o stepper, para escolha do dia que se deseja visualizar os eventos
- (IBAction)incrementador:(id)sender {
    
    UIStepper *incrementador = (UIStepper *) sender;
    self.qtdFunc.text= [NSString stringWithFormat:@"%D",
                        (int) incrementador.value ];
    
    
    NSString *str = [NSString stringWithFormat:@"%i", (int)incrementador.value ]; //converte a variavel de inteiro para string
    
    [self loadContacts:str];
    [self.tabelaDeEventos reloadData];
    
    
    
    
}
@end












