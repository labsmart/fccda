//
//  TelaCalendario.h
//  Projeto
//
//  Created by aluno on 5/20/15.

//  Lucas de Sá Moreira Bragança - 22314

//  Rafael José dos Reis Macieira - 28733

#import <UIKit/UIKit.h>
#import "Evento.h"

@interface TelaCalendario : UIViewController<UITableViewDelegate, UITableViewDataSource>{
    NSMutableArray *inserirEventos;
    Evento *ev;
}

- (IBAction)incrementador:(id)sender;

@property (weak, nonatomic) IBOutlet UITextField *qtdFunc;

@property (weak, nonatomic) IBOutlet UITableView *tabelaDeEventos;




@end
