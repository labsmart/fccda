//
//  Tela2.h
//  Projeto
//
//  Created by aluno on 5/20/15.

//  Lucas de Sá Moreira Bragança - 22314

//  Rafael José dos Reis Macieira - 28733

#import <UIKit/UIKit.h>

@interface Tela2 : UIViewController{
    IBOutlet UIScrollView *scroller;
}

@end
