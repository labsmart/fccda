//
//  TelaEventos.h
//  Projeto
//
//  Created by aluno on 5/20/15.

//  Lucas de Sá Moreira Bragança - 22314

//  Rafael José dos Reis Macieira - 28733

#import <UIKit/UIKit.h>
#import "Evento.h"


@interface TelaEventos : UIViewController{

Evento *ev;

}

-(TelaEventos*) initComObjeto : (Evento *) evento;

@property (weak, nonatomic) IBOutlet UITextView *caixaDeTexto;

@property (weak, nonatomic) IBOutlet UILabel *nomeEvento;

@property (weak, nonatomic) IBOutlet UILabel *nomeLocal;

@property (weak, nonatomic) IBOutlet UIImageView *imagem;

@property (weak, nonatomic) IBOutlet UIImageView *imgFundo;

@property (weak, nonatomic) IBOutlet UIScrollView *scroll;

@property (weak, nonatomic) IBOutlet UIButton *bt;

@property (weak, nonatomic) IBOutlet UILabel *btLink; // vai receber o link para pesquisa de mais informações

@property (weak, nonatomic) IBOutlet UILabel *info;

- (IBAction)BotaoLink:(id)sender;

@end
