//
//  ViewController.m
//  Projeto
//
//  Created by aluno on 5/20/15.
//  Copyright (c) 2015 aluno. All rights reserved.
//

#import "ViewController.h"
#import "Tela2.h"
#import "TelaCalendario.h"
@interface ViewController ()

@end



@implementation ViewController




- (void)viewDidLoad {
    [super viewDidLoad];
    
  //  NSString *finalString = [NSString stringWithFormat:@"asd"];

    
    
    
    
    //self.title = @"Tela principal";
    // Do any additional setup after loading the view from its nib.

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];

    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)sobreNos:(id)sender {
    
    Tela2 *tela = [[Tela2 alloc]init];
    [self.navigationController pushViewController:tela animated:YES];
    
}

- (IBAction)calendario:(id)sender {
    TelaCalendario *t = [[TelaCalendario alloc]init];
    [self.navigationController pushViewController:t animated:YES];
}

- (IBAction)testeButton:(id)sender {

  NSString *finalString = [NSString stringWithFormat:@"http://www.google.com"];
    
    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:finalString]];
}
@end
