//
//  TelaEventos.m
//  Projeto
//
//  Created by aluno on 5/20/15.

//  Lucas de Sá Moreira Bragança - 22314

//  Rafael José dos Reis Macieira - 28733

#import "TelaEventos.h"
#import "Evento.h"


@interface TelaEventos ()

@end

@implementation TelaEventos

@synthesize caixaDeTexto, nomeEvento, nomeLocal, imagem, imgFundo, scroll, info, bt;





- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
   if([ev.link isEqualToString:@"vazio"])
       [bt setHidden: YES ];
    
    [scroll setScrollEnabled:YES ];
    [self.scroll setContentSize:CGSizeMake(800, 0)];
    
    
    
    [self insereTextoNome:nomeEvento eLocal:nomeLocal eDescricao:caixaDeTexto];
    
    [caixaDeTexto setFont:[UIFont systemFontOfSize:18]];
    
    NSString *str =[ NSString stringWithFormat:@"%@.jpeg" ,ev.local ];
   
    UIImage *image = [ UIImage imageNamed:str ];
    self.imagem.image = image;
    
    UIImage *image2 = [ UIImage imageNamed:str ];
    self.imgFundo.image = image2;
    
    if([ev.link isEqualToString:@"vazio"]   ) {
        
        [info setHidden:YES];
       
    }
    
    }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(TelaEventos*) initComObjeto : (Evento *) evento{
   self =  [super init];
    if(self){
        ev = evento;
        
    }
    
    return self;
}

-(void) insereTextoNome:(UILabel*)tNome eLocal:(UILabel*) tLocal eDescricao:(UITextView*) texto{
   
    
    texto.text = ev.descricao;
    tNome.text = ev.nome;
    tLocal.text = ev.local;
    
    
    
}

- (IBAction)BotaoLink:(id)sender {
    
    
    

    
    NSString *finalString = [NSString stringWithFormat:@"%@",ev.link];
    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:finalString]];
    NSLog(@"%@", ev.link);
}


@end
