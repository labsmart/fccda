//
//  Tela2.m
//  Projeto
//
//  Created by aluno on 5/20/15.

//  Lucas de Sá Moreira Bragança - 22314

//  Rafael José dos Reis Macieira - 28733

#import "Tela2.h"

@interface Tela2 ()

@end

@implementation Tela2

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Sobre nós";
    // Do any additional setup after loading the view from its nib.
    
    [scroller setScrollEnabled:YES ];
    //[ scroller setContentSize:CGSizeMake(400, 624) ];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
