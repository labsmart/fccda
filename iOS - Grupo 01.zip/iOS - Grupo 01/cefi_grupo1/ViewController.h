//
//  ViewController.h
//  cefi_grupo1
//
//  Created by aluno on 06/05/15.
//  Copyright (c) 2015 Grupo04. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)trocatela:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *tableview;



@end

